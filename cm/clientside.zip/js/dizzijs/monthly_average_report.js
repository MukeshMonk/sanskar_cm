// JavaScript Document
// JavaScript Document
// JavaScript Document
// Configuration



// function loadorder_grahps(labls)
// {
// 
// 
// var barChart = c3.generate({
        // bindto: '#bar-chart1',
		// axisX:{
       // title: "axisX Title",
       // gridThickness: 1,
       // tickLength: 10
      // },
        // data: { x: 'x',
		    // columns: [
           // labls.class_n,
            // ['data1', 30, 80, 90]
//            
        // ],
// 			
            // type: 'bar'
        // },
		// axis: {
    // x: {
       // type: 'category',
// 	   
    // },
	// y: {
    // max: 100
  // }
  // },
        // bar: {
            // width: {
                // ratio: 0.5
            // }
// 			
        // }
    // });
// 
// 	
// }
// 
// 
// 
// jQuery(document).ready(function() {
//     
    // "use strict";
//     
//  
    // $.ajax({
            // //beforeSend: function(){ sendRequest("canvas"); },
            // cache: false,
            // type: "POST",
            // dataType: "json",
            // url:"clientside/socket/call.php",
            // data: "connector=monthly_avg_rpt",
            // success: function(data){
//               
                // loadorder_grahps(data);
            // },
        // });
//   
//   
//     
    // var delay = (function() {
	// var timer = 0;
	// return function(callback, ms) {
	    // clearTimeout(timer);
	    // timer = setTimeout(callback, ms);
	// };
    // })();
// 
    // jQuery(window).resize(function() {
	// delay(function() {
	    // m1.redraw();
	    // m2.redraw();
	    // m3.redraw();
	    // m4.redraw();
	    // m5.redraw();
	    // m6.redraw();
	// }, 200);
    // }).trigger('resize');
//   
// });




/*$(document).on('blur','#noofstudent',function(){	
	var value = $(this).val();	
	for(var i=0;i<value;i++)
	{
		var appendstudent = '<div class="row"><div class="col-md-12"><div class="form-group"><label for="field-1" class="control-label">Student ID<span class="mandatory"></span></label><input type="text" name="student_id1[]" class="form-control student_id1 required"/><i class="fa fa-times deletestudentiddiv"></i></div></div></div>';
		$(this).closest('.row').after(appendstudent);
	}	
});

$(document).on('click','.deletestudentiddiv',function(){	
	$(this).closest('.row').remove();	
});*/
