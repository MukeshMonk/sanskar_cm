<?	
	/*$obj_module_ad = new module_ad();
	$fields_to_update["todays_bill"]="0";
	$obj_module_ad->map_fields($fields_to_update);
	$obj_module_ad->execute("UPDATE", false, "", "is_daily_budget=1");*/
		
?>